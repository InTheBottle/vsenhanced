#version 330 core

uniform sampler2D inputTexture;
uniform sampler2D glowParts;


in vec2 texCoord;
in vec3 sunPosScreen;
in float iGlobalTime;
in float intensity;
in float direction;

out vec4 outColor;


// Falloff over distance
const float decay = 0.9985; 

vec3 getSunRayColor(vec2 nSunPos) {
	float sunHeight = clamp(nSunPos.y, 0.0, 1.0);
	float horizonWarmth = 1.0 - smoothstep(0.28, 0.68, sunHeight);
	vec3 lowSun = vec3(1.0, 0.68, 0.42);
	vec3 highSun = vec3(1.0, 0.92, 0.74);
	return mix(highSun, lowSun, horizonWarmth);
}


vec2 clampDeltas(vec2 dtuv) {
	// When looking 90 degrees away from the sun, dTuv gets very large and causes significant frame drops.
	// I presume this is because the graphics card local texture cache is no longer effective due to the large uv coord jumps
	if (length(dtuv) > 0.005) {
		dtuv = normalize(dtuv) * 0.005;
	}
	
	return dtuv;
}

vec4 applyGodRays(in vec2 uv, in vec2 nSunPos) {
	// Sample weight. Decays as we radiate outwards.
	float radialDistance = length(uv - nSunPos);
	float screenFade = smoothstep(1.15, 0.12, radialDistance);
	float horizonFade = smoothstep(0.02, 0.18, nSunPos.y) * (1.0 - smoothstep(0.96, 1.0, nSunPos.y));
	float rayStrength = smoothstep(0.08, 0.72, intensity) * horizonFade;
	float weight = rayStrength * screenFade / 78.0;
	
	int samples = int(mix(48.0, 120.0, rayStrength));
	
	// Short deltas near the sun
	vec2 sdTuv = clampDeltas((nSunPos - uv) * max(rayStrength, 0.08) / 220 * direction);
	
	// Large deltas far away from the sun where precision matters less and where is more important that the ray travels as far as possible
	vec2 ldTuv = clampDeltas((nSunPos - uv) * max(rayStrength, 0.08) / 84 * direction);
	
	vec2 dTuv = sdTuv;
	
	
	vec3 rayColor = getSunRayColor(nSunPos);
	float glow = texture(glowParts, uv).g;
    vec4 col = vec4(texture(inputTexture, uv).rgb * glow * rayColor * 0.18, glow * 0.18);
    
    for (float i=0.0; i < samples; i++) {
		uv.x = clamp(uv.x + dTuv.x, 0, 1);
		uv.y = clamp(uv.y + dTuv.y, 0, 1);
        float glowSample = texture(glowParts, uv).g;
        float mask = smoothstep(0.04, 0.6, glowSample);
        vec3 sampleColor = texture(inputTexture, uv).rgb;
        col.rgb += mix(rayColor, sampleColor * rayColor, 0.16) * mask * weight;
        col.a += mask * weight;
        weight *= decay;
		
		dTuv = mix(sdTuv, ldTuv, i/samples);
    }
	
	// Seems to greatly reduce the sun turning into one massive white blob
	float luma = dot(col.rgb, vec3(0.299, 0.587, 0.114));
	col.rgb *= 1.0 - smoothstep(0.28, 0.85, luma) * 0.35;
	col.rgb = min(col.rgb, vec3(0.32));
	
	col.a = min(1.0, col.a);
	
    return col;
}


void main(void) {
	vec2 nSunPos = (clamp(sunPosScreen.xy, -10, 10) + 1) / 2;	
	outColor = applyGodRays(texCoord, nSunPos);	
	
	outColor.a=1;
}
