#version 330 core

uniform sampler2D inputTexture;
uniform sampler2D glowParts;
uniform sampler2D realCloudShadowMap;
uniform float realCloudShadowMapWidth;
uniform vec3 realCloudShadowOffset;
uniform float realCloudShadowStrength;
uniform vec3 realCloudShadowLightDir;


in vec2 texCoord;
in vec3 sunPosScreen;
in float iGlobalTime;
in float intensity;
in float direction;

out vec4 outColor;


vec3 getSunRayColor() {
	float sunHeight = clamp(realCloudShadowLightDir.y, 0.0, 1.0);
	float horizonWarmth = 1.0 - smoothstep(0.28, 0.68, sunHeight);
	vec3 lowSun = vec3(1.0, 0.68, 0.42);
	vec3 highSun = vec3(1.0, 0.92, 0.74);
	vec3 sunColor = mix(highSun, lowSun, horizonWarmth);
	vec3 moonColor = vec3(0.58, 0.66, 0.88);
	float moonBlend = smoothstep(-1.0, -0.15, -direction);
	return mix(sunColor, moonColor, moonBlend * 0.72);
}

float sampleRayMask(vec2 uv) {
	vec4 glowData = texture(glowParts, clamp(uv, vec2(0.001), vec2(0.999)));
	return smoothstep(0.012, 0.30, glowData.g);
}

vec4 applyGodRays(in vec2 uv) {
	float rayStrength = smoothstep(0.025, 0.42, intensity);
	if (rayStrength <= 0.002) {
		return vec4(0.0);
	}

	vec3 rayColor = getSunRayColor();
	vec2 s1 = vec2(0.0018, 0.0012);
	vec2 s2 = vec2(0.0044, 0.0031);
	vec2 s3 = vec2(0.0080, 0.0058);
	float mask = sampleRayMask(uv) * 0.30;
	mask += sampleRayMask(uv + vec2( s1.x,  s1.y)) * 0.085;
	mask += sampleRayMask(uv + vec2(-s1.x, -s1.y)) * 0.085;
	mask += sampleRayMask(uv + vec2(-s1.y,  s1.x)) * 0.075;
	mask += sampleRayMask(uv + vec2( s1.y, -s1.x)) * 0.075;
	mask += sampleRayMask(uv + vec2( s2.x,  s2.y)) * 0.055;
	mask += sampleRayMask(uv + vec2(-s2.x, -s2.y)) * 0.055;
	mask += sampleRayMask(uv + vec2(-s2.y,  s2.x)) * 0.045;
	mask += sampleRayMask(uv + vec2( s2.y, -s2.x)) * 0.045;
	mask += sampleRayMask(uv + vec2( s3.x,  s3.y)) * 0.030;
	mask += sampleRayMask(uv + vec2(-s3.x, -s3.y)) * 0.030;
	mask += sampleRayMask(uv + vec2(-s3.y,  s3.x)) * 0.025;
	mask += sampleRayMask(uv + vec2( s3.y, -s3.x)) * 0.025;

	mask = smoothstep(0.03, 0.70, mask) * rayStrength;
	vec4 col = vec4(rayColor * mask * 0.34, mask * 0.20);
	
	float luma = dot(col.rgb, vec3(0.299, 0.587, 0.114));
	col.rgb *= 1.0 - smoothstep(0.12, 0.30, luma) * 0.45;
	col.rgb = min(col.rgb, vec3(0.16));
	
	col.a = min(1.0, col.a);
	
    return col;
}


void main(void) {
	outColor = applyGodRays(texCoord);
	
	outColor.a=1;
}
