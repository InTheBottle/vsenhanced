uniform sampler2D liquidDepth;
uniform float cameraUnderwater;
uniform vec2 frameSize;
uniform vec4 waterMurkColor;
uniform sampler2D realCloudShadowMap;
uniform float realCloudShadowMapWidth;
uniform vec3 realCloudShadowOffset;
uniform float realCloudShadowStrength;
uniform vec3 realCloudShadowLightDir;
uniform float realCloudShadowDaylight;
uniform float realMoonLightStrength;

float getSkyMurkiness() {
	if (cameraUnderwater > 0.7) {
		return 0.0;
	}
	
	// Smoother ocean edge
	float ldepth1 = linearDepth(texture(liquidDepth, gl_FragCoord.xy/frameSize.xy).r);
	float ldepth2 = linearDepth(texture(liquidDepth, (gl_FragCoord.xy + vec2(0,3))/frameSize.xy).r);
	float ldepth3 = linearDepth(texture(liquidDepth, (gl_FragCoord.xy + vec2(0,6))/frameSize.xy).r);
	
	return 1-(ldepth1+ldepth2+ldepth3)/3.0;
}

float getUnderwaterMurkiness() {
	if (cameraUnderwater > 0.7) {
		return 0.0;
	}

	// We render the liquid depth z-buffer at 1/4th the resolution. This seems to cause black lines near the shore line
	// when there is strong fog. Probably because of the harsh transition of fog level above vs below water
	// Seems to be fixable by either doing full resolution render or doing a second sample. Pretty sure 2 texture reads on a tiny texture is way faster
	// so lets do that.
	float ldepth = linearDepth(
		max(
			texture(liquidDepth, gl_FragCoord.xy/frameSize.xy).r,
			texture(liquidDepth, (gl_FragCoord.xy + vec2(0,3))/frameSize.xy).r
		)
	);
	
	float fdepth = linearDepth(gl_FragCoord.z);
	return clamp(max(0.0, fdepth - ldepth)*350.0, 0.0, 1.0);
}

float causticFilament(vec2 p, float t) {
	float n1 = gnoise(vec3(p + vec2(t, -t * 0.72), t * 0.15));
	float n2 = gnoise(vec3(p * 1.74 + vec2(-t * 0.47, t * 0.84), t * 0.21));
	float ridges = 1.0 - abs(n1 - n2);
	ridges *= 0.82 + 0.18 * n1;
	return smoothstep(0.52, 0.90, pow(clamp(ridges, 0.0, 1.0), 11.0));
}

float getCausticLight(vec3 worldPos, float murkiness) {
	if (murkiness <= 0.001) return 0.0;
	
	vec2 p = worldPos.xz * 0.58;
	float t = windWaveCounter * 0.115;
	float depthFade = smoothstep(0.035, 0.22, murkiness) * (1.0 - smoothstep(0.78, 1.0, murkiness));
	float broad = causticFilament(p, t);
	float fine = causticFilament(p * 2.15 + vec2(11.7, -4.3), t * 1.18);
	float sparkle = pow(max(0.0, broad * 0.46 + fine * 0.36), 2.25);
	float daylightBoost = 0.10 + clamp(realCloudShadowDaylight, 0.0, 1.0) * 0.12;
	return sparkle * depthFade * daylightBoost;
}

vec3 applyUnderwaterEffects(vec3 color, float murkiness) {
	vec3 murkColor = waterMurkColor.rgb * 0.4;
	return mix(color.rgb, murkColor, murkiness);
}

vec3 applyUnderwaterEffectsAt(vec3 color, float murkiness, vec3 worldPos) {
	vec3 murkColor = waterMurkColor.rgb * 0.4;
	vec3 causticColor = mix(vec3(0.45, 0.72, 0.86), vec3(0.76, 0.86, 0.78), clamp(realCloudShadowDaylight, 0.0, 1.0) * 0.28);
	float waterShadow = smoothstep(0.18, 0.95, murkiness) * 0.18;
	vec3 shadedColor = mix(color.rgb, murkColor, murkiness) * (1.0 - waterShadow);
	return shadedColor + causticColor * getCausticLight(worldPos, murkiness);
}

vec3 applyMoonDirectLight(vec3 color, vec3 normal, float fogAmount) {
	float moon = clamp(realMoonLightStrength, 0.0, 1.0);
	if (moon <= 0.001) return color;

	float upness = clamp(normal.y * 0.5 + 0.5, 0.0, 1.0);
	float ndl = max(0.0, dot(normalize(normal), normalize(realCloudShadowLightDir)));
	float direct = pow(ndl, 0.85) * upness * moon * (1.0 - smoothstep(0.38, 0.92, fogAmount));
	vec3 moonTint = vec3(0.46, 0.55, 0.78);
	return color + (color * moonTint * 0.22 + vec3(0.006, 0.009, 0.017)) * direct;
}

float vspVolumetricJitter(vec2 p) {
	return fract(0.75487765 * p.x + 0.56984026 * p.y);
}

float vspVolumetricPhase(float cosTheta) {
	return 0.58 + 0.08 * cosTheta * cosTheta;
}

float calculateVspVolumetricScatter(vec3 viewPos, vec3 normal, float fogAmount) {
#if GODRAYS > 0 && SHADOWQUALITY > 0
	if (sunlightLevel < 0.002 || fogAmount > 0.96) {
		return 0.0;
	}
	if (shadowRayStart.w <= 0.0001 || shadowCoordsFar.w <= 0.0001 || shadowCoordsFar.z >= 0.999 ||
		shadowCoordsFar.x <= 0.02 || shadowCoordsFar.x >= 0.98 ||
		shadowCoordsFar.y <= 0.02 || shadowCoordsFar.y >= 0.98) {
		return 0.0;
	}

	const int maxSamples = 5;
	vec3 dV = (shadowCoordsFar.xyz - shadowRayStart.xyz) / float(maxSamples);
	float rayStepLength = length(dV);
	if (rayStepLength < 0.00001) {
		return 0.0;
	}

	float viewDistance = length(viewPos);
	if (viewDistance < 7.0) {
		return 0.0;
	}

	vec3 progress = shadowRayStart.xyz + dV * vspVolumetricJitter(gl_FragCoord.xy);
	float segmentDepth = clamp(viewDistance / 820.0 / float(maxSamples), 0.018, 0.26);
	float stepScatter = 1.0 - exp(-segmentDepth);
	float stepTransmittance = exp(-segmentDepth);
	float transmittance = 1.0;
	float scattered = 0.0;

	for (int i = 0; i < maxSamples; i++) {
		float inLight = texture(shadowMapFar, vec3(progress.xy, progress.z - 0.0009));
		scattered += inLight * stepScatter * transmittance;
		transmittance *= stepTransmittance;
		if (transmittance < 0.035) break;
		progress += dV;
	}

	float normalOut = clamp(scattered * 2.8, 0.0, 1.0);
	float shadowLightLen = max(length(shadowLightPos.xyz), 0.00001);
	float phase = vspVolumetricPhase(dot(dV / rayStepLength, shadowLightPos.xyz / shadowLightLen));
	float daylight = clamp(realCloudShadowDaylight + realMoonLightStrength * 0.55, 0.0, 1.0);
	float fogGate = 1.0 - smoothstep(0.58, 0.98, fogAmount);
	float shaped = clamp(normalOut * phase * daylight * fogGate, 0.0, 1.0);
	return min(0.58, pow(shaped, 0.82) * 0.52);
#endif
	return 0.0;
}

vec4 applyWetSurface(vec4 texColor, vec3 normal, vec3 worldPos, float fogAmount, float glowLevel) {
	return texColor;
}

float getProceduralCloudShadow(vec3 worldPos, vec3 normal, float fogAmount) {
	float upness = clamp(normal.y * 0.5 + 0.5, 0.0, 1.0);
	float daylight = smoothstep(0.04, 0.32, lightPosition.y);
	float fogFade = 1.0 - smoothstep(0.45, 0.9, fogAmount);
	if (upness <= 0.05 || daylight <= 0.01 || fogFade <= 0.01) return 1.0;
	
	vec2 drift = vec2(windWaveCounter * 0.004, -windWaveCounter * 0.002);
	vec2 p = worldPos.xz * 0.0035 + drift;
	float broad = gnoise(vec3(p, 0.0)) * 0.5 + 0.5;
	float detail = gnoise(vec3(p * 2.3 + vec2(17.0, -9.0), 0.0)) * 0.5 + 0.5;
	float cloud = smoothstep(0.46, 0.72, broad * 0.78 + detail * 0.22);
	float strength = cloud * upness * daylight * fogFade * (0.55 + shadowIntensity * 0.45);
	
	return 1.0 - strength * 0.32;
}

float sampleRealCloudDensity(vec2 mapPos) {
	vec2 uv = mapPos / realCloudShadowMapWidth;
	if (uv.x <= 0.001 || uv.y <= 0.001 || uv.x >= 0.999 || uv.y >= 0.999) return 0.0;
	
	vec2 texel = vec2(1.0 / realCloudShadowMapWidth);
	float density = texture(realCloudShadowMap, uv).r * 0.42;
	density += texture(realCloudShadowMap, uv + texel * vec2( 1.5,  0.0)).r * 0.145;
	density += texture(realCloudShadowMap, uv + texel * vec2(-1.5,  0.0)).r * 0.145;
	density += texture(realCloudShadowMap, uv + texel * vec2( 0.0,  1.5)).r * 0.145;
	density += texture(realCloudShadowMap, uv + texel * vec2( 0.0, -1.5)).r * 0.145;
	return density;
}

float getCloudShadow(vec3 worldPos, vec3 normal, float fogAmount) {
	float upness = clamp(normal.y * 0.5 + 0.5, 0.0, 1.0);
	float daylight = smoothstep(0.04, 0.32, lightPosition.y);
	float fogFade = 1.0 - smoothstep(0.45, 0.9, fogAmount);
	if (upness <= 0.05 || daylight <= 0.01 || fogFade <= 0.01) return 1.0;
	
	if (realCloudShadowStrength <= 0.01 || realCloudShadowMapWidth <= 1.0) {
		return getProceduralCloudShadow(worldPos, normal, fogAmount);
	}
	
	float cloudTileSize = 50.0;
	float rayHeight = max(realCloudShadowOffset.y - worldPos.y, 0.0);
	vec2 projected = worldPos.xz + lightPosition.xz * (rayHeight / max(lightPosition.y, 0.08));
	vec2 mapPos = (projected - realCloudShadowOffset.xz) / cloudTileSize + realCloudShadowMapWidth * 0.5;
	float cloud = smoothstep(0.01, 0.32, sampleRealCloudDensity(mapPos));
	float strength = cloud * upness * daylight * fogFade * (0.55 + shadowIntensity * 0.45) * realCloudShadowStrength;
	
	return 1.0 - strength * 0.38;
}
