#version 330 core

uniform sampler2D inputTexture;
uniform sampler2D glowParts;
uniform sampler2D realCloudShadowMap;
uniform float realCloudShadowMapWidth;
uniform vec3 realCloudShadowOffset;
uniform float realCloudShadowStrength;
uniform vec3 realCloudShadowLightDir;


in vec2 texCoord;
in vec3 sunPosScreen;
in float iGlobalTime;
in float intensity;
in float direction;

out vec4 outColor;


// Falloff over distance
const float decay = 0.972;

vec3 getSunRayColor() {
	float sunHeight = clamp(realCloudShadowLightDir.y, 0.0, 1.0);
	float horizonWarmth = 1.0 - smoothstep(0.28, 0.68, sunHeight);
	vec3 lowSun = vec3(1.0, 0.68, 0.42);
	vec3 highSun = vec3(1.0, 0.92, 0.74);
	vec3 sunColor = mix(highSun, lowSun, horizonWarmth);
	vec3 moonColor = vec3(0.58, 0.66, 0.88);
	float moonBlend = smoothstep(-1.0, -0.15, -direction);
	return mix(sunColor, moonColor, moonBlend * 0.72);
}

float sampleCloudBreakup(vec2 uv, float stepIndex) {
	if (realCloudShadowStrength <= 0.01 || realCloudShadowMapWidth <= 1.0) {
		return 1.0;
	}

	vec2 wind = realCloudShadowOffset.xz / max(realCloudShadowMapWidth * 50.0, 1.0);
	vec2 lightDrift = normalize(realCloudShadowLightDir.xz + vec2(0.0001)) * 0.035;
	vec2 mapUv = fract(vec2(0.5) + wind + uv * vec2(0.72, 0.58) + lightDrift + stepIndex * lightDrift * 0.012);
	vec2 texel = vec2(1.0 / realCloudShadowMapWidth);

	float density = texture(realCloudShadowMap, mapUv).r * 0.60;
	density += texture(realCloudShadowMap, mapUv + texel * vec2( 1.35,  0.0)).r * 0.14;
	density += texture(realCloudShadowMap, mapUv + texel * vec2( 0.0, -1.35)).r * 0.14;

	float clearGap = 1.0 - smoothstep(0.12, 0.62, density);
	float silverEdge = smoothstep(0.08, 0.34, density) * (1.0 - smoothstep(0.48, 0.92, density));
	float blocker = smoothstep(0.58, 0.95, density);
	return clamp(0.72 + clearGap * 0.50 + silverEdge * 0.52 - blocker * 0.22, 0.34, 1.56);
}

float sampleRayMask(vec2 uv, float stepIndex) {
	vec4 glowData = texture(glowParts, clamp(uv, vec2(0.001), vec2(0.999)));
	float volumeShaft = smoothstep(0.018, 0.42, glowData.g);
	float cloudEdgeSource = smoothstep(0.18, 0.56, glowData.a) * (1.0 - smoothstep(0.80, 1.0, glowData.a));
	float breakup = sampleCloudBreakup(uv, stepIndex);
	return clamp((volumeShaft + cloudEdgeSource * 0.10) * breakup, 0.0, 1.0);
}


vec2 clampDeltas(vec2 dtuv) {
	// When looking 90 degrees away from the sun, dTuv gets very large and causes significant frame drops.
	// I presume this is because the graphics card local texture cache is no longer effective due to the large uv coord jumps
	if (length(dtuv) > 0.005) {
		dtuv = normalize(dtuv) * 0.005;
	}
	
	return dtuv;
}

vec2 getStableRayDirection(vec2 rawLightPos) {
	vec2 rayDir = rawLightPos - vec2(0.5);
	if (dot(rayDir, rayDir) < 0.0001) {
		rayDir = normalize(realCloudShadowLightDir.xz + vec2(0.0001));
	}
	return normalize(rayDir);
}

vec4 applyGodRays(in vec2 uv, in vec2 rawLightPos) {
	float cloudVeil = sampleCloudBreakup(uv, 0.0);
	float rayStrength = smoothstep(0.035, 0.44, intensity) * (0.82 + cloudVeil * 0.18);
	if (rayStrength <= 0.002) {
		return vec4(0.0);
	}

	vec2 rayDir = getStableRayDirection(rawLightPos);
	float offscreen = smoothstep(0.58, 1.25, length(rawLightPos - vec2(0.5)));
	float weight = rayStrength * mix(0.018, 0.025, offscreen);

	const int samples = 52;

	vec2 nearStep = clampDeltas(rayDir * (0.0022 + rayStrength * 0.0025));
	vec2 farStep = clampDeltas(rayDir * (0.0050 + rayStrength * 0.0030));
	vec2 dTuv = nearStep;

	vec3 rayColor = getSunRayColor();
	float glow = sampleRayMask(uv, 0.0);
	vec4 col = vec4(rayColor * glow * rayStrength * 0.045, glow * 0.05);
    
    for (int i = 0; i < samples; i++) {
		float fi = float(i);
		uv = clamp(uv + dTuv, vec2(0.0), vec2(1.0));
        float mask = sampleRayMask(uv, fi);
		float airSparkle = 0.92 + 0.08 * sin(fi * 2.37 + iGlobalTime * 0.7);
		float mist = smoothstep(0.08, 0.75, fi / float(samples - 1));
        col.rgb += rayColor * mask * weight * airSparkle * mix(0.70, 1.10, mist);
        col.a += mask * weight * 0.75;
        weight *= decay;
		
		dTuv = mix(nearStep, farStep, fi / float(samples - 1));
    }
	
	// Seems to greatly reduce the sun turning into one massive white blob
	float luma = dot(col.rgb, vec3(0.299, 0.587, 0.114));
	col.rgb *= 1.0 - smoothstep(0.16, 0.36, luma) * 0.38;
	col.rgb = min(col.rgb, vec3(0.22));
	
	col.a = min(1.0, col.a);
	
    return col;
}


void main(void) {
	vec2 rawLightPos = (sunPosScreen.xy + 1) / 2;
	outColor = applyGodRays(texCoord, rawLightPos);
	
	outColor.a=1;
}
